import React, { useEffect, useState } from 'react';
import './TimeDisplay.css';

const TimeDisplay = () => {
  const [times, setTimes] = useState({
    india: '',
    london: '',
    dubai: '',
    amsterdam: ''
  });

  const updateTime = () => {
    const indiaTime = new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata", hour: '2-digit', minute: '2-digit', hour12: false });
    const londonTime = new Date().toLocaleString("en-US", { timeZone: "Europe/London", hour: '2-digit', minute: '2-digit', hour12: false });
    const dubaiTime = new Date().toLocaleString("en-US", { timeZone: "Asia/Dubai", hour: '2-digit', minute: '2-digit', hour12: false });
    const amsterdamTime = new Date().toLocaleString("en-US", { timeZone: "Europe/Amsterdam", hour: '2-digit', minute: '2-digit', hour12: false });

    setTimes({
      india: indiaTime,
      london: londonTime,
      dubai: dubaiTime,
      amsterdam: amsterdamTime
    });
  };

  useEffect(() => {
    updateTime();
    const interval = setInterval(updateTime, 60000); 
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="time-container">
      <div className="time" id="india-time">
        <span className="time-text">INDIA: {times.india}</span>
        <span className="hover-text">Contact Now</span>
      </div>
      <div className="time" id="london-time">
        <span className="time-text">London: {times.london}</span>
        <span className="hover-text">Contact Now</span>
      </div>
      <div className="time" id="dubai-time">
        <span className="time-text">Dubai: {times.dubai}</span>
        <span className="hover-text">Contact Now</span>
      </div>
      <div className="time" id="amsterdam-time">
        <span className="time-text">Amsterdam:  {times.amsterdam}</span>
        <span className="hover-text">Contact Now</span>
      </div>
    </div>
  );
};

export default TimeDisplay;
