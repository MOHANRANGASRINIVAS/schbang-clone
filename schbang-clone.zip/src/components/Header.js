import React from 'react';
import './Header.css';
import headerGif from '../assets/images/header-animation.gif'; 
import { redirect } from 'react-router-dom';
import rotatingImage from '../assets/images/rotating-image.png'; 
import dropdownImage1 from '../assets/images/dropdown-image1.png'; // Example image
import dropdownImage2 from '../assets/images/dropdown-image2.png'; // Example image
import dropdownImage3 from '../assets/images/dropdown-image3.png'; // Example image
import dropdownImage4 from '../assets/images/dropdown-image4.png'; // Example image
import dropdownImage5 from '../assets/images/dropdown-image5.png'; // Example image
import dropdownImage6 from '../assets/images/dropdown-image6.webp'; // Example image


const Header = () => {
    return (
        <header>
            <nav>
                <img src={headerGif} alt="Header Animation" className="header-gif" />
                <ul>
                    <li><a href="/">Home</a></li>
                    <li className="dropdown">
                        <a href="/solutions">solutions <span className="arrow">&#8744;</span></a>
                        <div className="dropdown-content">
                            <div className="dropdown-item">
                                <img src={dropdownImage3} alt="Dropdown 1" />
                                <p style={{textAlign:'center'}}>Text for dropdown item 1</p>
                            </div>
                            <div className="dropdown-item">
                                <img src={dropdownImage4} alt="Dropdown 2" />
                                <p style={{textAlign:'center'}}>     Text for dropdown item 2</p>
                            </div>
                            
                        </div>
                    </li>
                    
                    <li className="dropdown">
                        <a href="/about">About <span className="arrow">&#8744;</span></a>
                        <div className="dropdown-content">
                            <div className="dropdown-item">
                                <img src={dropdownImage1} alt="Dropdown 1" />
                                <p style={{textAlign:'center'}}>Text for dropdown item 1</p>
                            </div>
                            <div className="dropdown-item">
                                <img src={dropdownImage2} alt="Dropdown 2" />
                                <p style={{textAlign:'center'}}>     Text for dropdown item 2</p>
                            </div>
                            
                        </div>
                    </li>
                    <li className="dropdown">
                        <a href="/RESOURCES">RESOURCES <span className="arrow">&#8744;</span></a>
                        <div className="dropdown-content">
                            <div className="dropdown-item">
                                <img src={dropdownImage5} alt="Dropdown 1" />
                                <p style={{textAlign:'center'}}>Text for dropdown item 1</p>
                            </div>
                            <div className="dropdown-item">
                                <img src={dropdownImage6} alt="Dropdown 2" />
                                <p style={{textAlign:'center'}}>     Text for dropdown item 2</p>
                            </div>
                            
                        </div>
                    </li>
                    <li><a href="/services">Services</a></li>
                    <li><a href="/contact" className="contact-button">contact us <span> &#10143;</span></a></li>
                </ul>
                <h1 style={{fontSize:60,padding:20,textAlign:'left',paddingTop:100.}}> 
                     Your Creative, Media & Technology <br>
                </br>Transformation Partner
                </h1>
                <h3 style={{textAlign:'left',color:'gray' ,display:'block',padding:20}}>
                We're a team of  1000+ Specialists delivering award-winning work for 300+ brands worldwide, 8 years and counting!
                </h3>
                
            </nav>
            <div className="scrolling-text">
                <p>
                    <img src={rotatingImage} alt="Rotating" className="rotating-image" /> 

                    ITS TIME TO CREATE A SHABANG

                    <img src={rotatingImage} alt="Rotating" className="rotating-image" />

                    ITS TIME TO CREATE A SHABANG

                    <img src={rotatingImage} alt="Rotating" className="rotating-image" /> 

                    ITS TIME TO CREATE A SHABANG

                    <img src={rotatingImage} alt="Rotating" className="rotating-image" />

                    ITS TIME TO CREATE A SHABANG

                    <img src={rotatingImage} alt="Rotating" className="rotating-image" /> 
                    
                    

                    
                </p>
            </div>
            

        </header>
    );
};

export default Header;
