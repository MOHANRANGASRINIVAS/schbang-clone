// src/components/Footer.js
import React from 'react';
import './Footer.css';
import one from '../assets/images/1.png';


const Footer = () => {
    return (
        <footer>
            {/* Footer elements */}
            <div style={{position:'relative',right:60,}}>
                <img src={one}/>
            </div>
            <p>© 2024 Schbang. All rights reserved.</p>
        </footer>
    );
};

export default Footer;
