/* src/App.js */
import React from 'react';
import { BrowserRouter as Router, Route, Switch, Routes } from 'react-router-dom';
import Header from './components/Header';
import Home from './pages/Home';


function App() {
    return (
        <Router>
            <div className="App">
                <Header />
                <Routes>
                    <Route path="/" exact component={Home} />
                    {}
                </Routes>
                

            </div>
        </Router>
    );
}

export default App;
