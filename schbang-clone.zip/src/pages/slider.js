import React, { useState } from 'react';
import './Slider.css';

const Slider = () => {
    const [activeIndex, setActiveIndex] = useState(0);

    const handleMouseEnter = (index) => {
        setActiveIndex(index);
    };

    const slides = [
        { id: 'slide1', content: "BRAND SOLUTION", hoverContent: "Additional content for slide 1" },
        { id: 'slide2', content: "TECH SOLUTION", hoverContent: "Additional content for slide 1" },
        { id: 'slide3', content: "MEDIA SOLUTION", hoverContent: "Additional content for slide 1" },
        { id: 'slide4', content: "RESEARCH SOLUTION", hoverContent: "Additional content for slide 1" },
        { id: 'slide5', content: "FILM SOLUTION", hoverContent: "Additional content for slide 1" }
    ];

    return (
        <div className="slider-container">
            <div className="slider" style={{ transform: `translateX(-${activeIndex * 33.3333}%)` }}>
                {slides.map((slide, index) => (
                    <div
                        key={slide.id}
                        id={slide.id}
                        className="slider-item"
                        onMouseEnter={() => handleMouseEnter(index === 2 ? 1 : index === 3 ? 2 : 0)}
                    >
                         <p className="slider-text">{slide.content}</p>
                         <p className="hover-content">{slide.hoverContent}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Slider;
