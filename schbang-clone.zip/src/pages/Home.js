import React, { useRef, useState, useEffect } from 'react';
import './Home.css';
import videoSrc from '../assets/images/Meet Schbang _ Agency Reel.mp4'; 
import Header from '../components/Header';
import Footer from '../components/Footer';
import Slider from './slider';
import Arrow from '../components/arrow';
import TimeDisplay from '../components/TimeDisplay';


const Home = () => {
    const videoRef = useRef(null);
    const [isMuted, setIsMuted] = useState(true);
    const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 });
    const [isHovering, setIsHovering] = useState(false);

    const handleUnmute = () => {
        if (videoRef.current) {
            videoRef.current.muted = !videoRef.current.muted;
            setIsMuted(videoRef.current.muted);
        }
    };

    const handleMouseMove = (e) => {
        setCursorPosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseEnter = () => {
        setIsHovering(true);
        window.addEventListener('mousemove', handleMouseMove);
    };

    const handleMouseLeave = () => {
        setIsHovering(false);
        window.removeEventListener('mousemove', handleMouseMove);
    };

    useEffect(() => {
        const videoElement = videoRef.current;
        if (videoElement) {
            videoElement.addEventListener('mouseenter', handleMouseEnter);
            videoElement.addEventListener('mouseleave', handleMouseLeave);
        }
        return () => {
            if (videoElement) {
                videoElement.removeEventListener('mouseenter', handleMouseEnter);
                videoElement.removeEventListener('mouseleave', handleMouseLeave);
            }
        };
    }, []);

    return (
        <div className="home">
            <Header/>
            <video
                ref={videoRef}
                src={videoSrc}
                autoPlay
                loop
                muted
                className="background-video"
            ></video>
            <div
                className="unmute-overlay"
                onClick={handleUnmute}
                style={{ left: cursorPosition.x, top: cursorPosition.y }}
            >
                {isMuted ? "Unmute" : ""}
            </div>
            <div style={{fontSize:40,position:'relative',left:25,top:80}}>
                WHAT'S DEFINE US
            </div>
            <Arrow/>
            
            <div style={{fontSize:30,position:'relative',left:530,paddingBottom:30,bottom:190}}>
            We’re brand builders at heart, creators by design, tech <br></br>
            enthusiasts in practice, and integrated at our core.
            </div>
            <div style={{fontSize:15,position:'relative',left:530,paddingBottom:10,bottom:190}}>
            We're on a mission to take the very best of Indian creative talent to the world. Driven by a <br></br>ferocious hunger to create tangible impact for your business, we work with in-house specialists,<br></br> industry partners and technology leaders to push the boundaries of creativity and put your brand on the global stage.
            </div>
            <li><a  className="contacts-button">Drive Into Our Culture <span> &#10143;</span></a></li>
            <Slider/>
            <TimeDisplay/>
            <Footer/>

            
        </div>
        
        
    );
};

export default Home;
