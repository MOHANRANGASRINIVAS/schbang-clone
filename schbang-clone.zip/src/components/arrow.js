import React from 'react';
import './arrow.css';




const Arrow= ()=>{
  return(
    <div class="container">
    <i class="fa fa-arrow-left">&#8592;</i>
  </div>

  );
};
export default Arrow;